//PART1 Seleccionar i Modificar Elements


const titol = document.querySelector('titol')
const paragraf = document.querySelector('paragraf')

document.querySelector('h1').textContent = 'Javascript1' //cambiar texto

document.querySelector('h1').style.fontSize = '80px' //cambiar tamaño de la letra

document.querySelector('h1').classList.add('pink') //añadir una clase al h1

document.querySelector('p').textContent = 'pratica01-ROSI' //cambiar texto
document.querySelector('p').classList.add("negrita"); //poner texto en negrita con css

document.querySelector('p').style.fontSize = '30px' //cambiar tamaño de la letra

document.querySelector('p').style.textAlign = 'center'; //centrar texto
document.querySelector('h1').style.textAlign = 'center'; //centrar texto


//**PART 2: Afegir Esdeveniments d’Usuari*

// Agregar evento de clic al botón
document.getElementById('canviarText').addEventListener('click', function() {
    const h1 = document.querySelector('h1')
    h1.textContent= 'Hola Rosi Has canviat el text';
    h1.style.color = 'purple';
});


//**PART 3: Afegir i Eliminar Elements*

//afegir elements con el boton
document.getElementById('afegirElement').addEventListener('click', function() {
    const llista = document.querySelector('ul');
    const element = document.createElement('li');
    element.textContent = 'Nou Element afegit';
    llista.appendChild(element);
})

//per  eliminar elementos de la llista con el boton 
document.getElementById('eliminarElement').addEventListener('click', function() {
   const llista = document.getElementById('llista');
   if (llista.children.length > 0) {
       llista.removeChild(llista.lastElementChild);
   }
})


//**PART 4: Aplicació d'Estils amb CSS*

//des de el css, he afegit una clase per canviar el color de fons
// i una clase per canviar el estilo de los botones
